import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';

export const LayDanhMucCon = createAsyncThunk(
  'category/subCate',
  async data => {
    const response = await fetch(
      `http://192.168.91.238:3000/categories/api/getCateByParentId?parentCateId=${data}`,
    );
    if (!response.ok) {
      throw new Error('Failed');
    }

    return await response.json();
  },
);

//tạo Slice quản lý trạng thái khi gọi hàm DangKyTaiKhoan
export const subCateSlice = createSlice({
  name: 'getSubCate',
  initialState: {
    subCateData: {},
    subCateStatus: 'khoitao',
  },
  reducers: {},
  extraReducers: builder => {
    builder
      .addCase(LayDanhMucCon.pending, (state, action) => {
        state.subCateStatus = 'loading';
      })
      .addCase(LayDanhMucCon.fulfilled, (state, action) => {
        state.subCateStatus = 'succeeded';
        state.subCateData = action.payload;
      })
      .addCase(LayDanhMucCon.rejected, (state, action) => {
        state.subCateStatus = 'failed';
        console.log(action.error.message);
      });
  },
});

export default subCateSlice.reducer;
