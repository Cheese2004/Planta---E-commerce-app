import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ThongBao = () => {
  return (
    <View>
      <Text>ThongBao</Text>
    </View>
  )
}

export default ThongBao

const styles = StyleSheet.create({})